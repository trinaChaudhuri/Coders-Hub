import React from 'react'
import ReactDOM from 'react-dom'
import todoitem from './todoitem'
function todo(){
    return(
        <div>
            <h1>TO-DO LIST</h1>
            <todoitem />
            <todoitem />
            <todoitem />
        </div>
    )
}
ReactDOM.render(<todo />,document.getElementById("todo"))