import React from 'react'
function todoitem(){
    return(
        <div>
            <input type="checkbox" />Something A<br></br>
            <input type="checkbox" />Something B<br></br>
            <input type="checkbox" />Something C<br></br>
        </div>
    )
}
export default todoitem